// Slider de imagens automático
// O CSS já controla a animação, este arquivo pode estar vazio ou ser usado para controles futuros

